// Checks the input
char checkInput(char bit);

// Acquires pulse width
int getPulseWidth(int temp);

// Prints to LCD the object's
void printObjectDistance (int x);

// Prints the LCD interface
void printLCDinterface();

// Deals with EEPROM values
void EEPROMcount();

// ADC functions and variables
void adc_init(unsigned char);

// Serial communications functions and variables
void serial_init(unsigned short);

// Sends out a string
void serial_stringout(char *);

// Sends characters to remote device
void serial_txchar(char);

// Initializes buzzer
void buzzerInit();

// Initializes encoder
void encoderInit();

// Initializes the serial
void serialInitilize();

// Initializes the buttons and LEDs
void button_led_init();