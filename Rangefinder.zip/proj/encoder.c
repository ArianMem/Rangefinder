#include "rangefinder.h"

void encoderInit(){

	/**************************************************************/

	// Initialize DDR and PORT registers for the rot. encoder
	PORTB |= (1 << PB3)|(1 << PB4);

	// Read the A and B inputs to determine the intial state
	// Defining values of a and b
	a = (temp & (1 << 3)) != 0;
	b = (temp & (1 << 4)) != 0;

	if (!b && !a)
		old_state = 0;
	else if (!b && a)
		old_state = 1;
	else if (b && !a)
		old_state = 2;
	else
		old_state = 3;

	// Redefining state values, and defining PCICR, and PCMSK1
	new_state = old_state;
	PCICR |= (1 << PCIE0);
	PCMSK0 |= (1 << PCINT3)|(1 << PCINT4);

/* Rot encoder initializations *******************************/
}


void buzzerInit(){
	/* ISR FOR THE BUZZER*/

	// Initialize appropriate registers for the buzzer itself
	DDRC |= (1 << PC4);

	// Set to CTC mode;
	TCCR0B |= (1 << WGM12);
	
	// Enable Timer Interrupt
	TIMSK0 |= (1 << OCIE0A);

	// Load the MAX count
	OCR0A = 80;

	// Set prescalar = 256
	TCCR0B |= (1 << CS12);

/********************/
}