#include "rangefinder.h"

void serialInitilize(){

/* Definitions for the Serial interface*************************/
  // Value for UBRR0 register
	serial_init(MYUBRR);

    UBRR0 = MYUBRR;             // Set baud rate
                                          // 1 stop bit, 8 data bits
    UCSR0B |= (1 << TXEN0 | 1 << RXEN0);  // Enable RX and TX

    DDRD |= (1 << 1);
    DDRD &= ~(1 << 0);
    PORTD |= (1 << 0);

/**************************************************************/
}