#include "rangefinder.h"

void button_led_init(){

    // Initialize registers for buttons
    DDRC &= ~((1 << 1)|(1 << 2));
    PORTC |= (1 << 1)|(1 << 2);

    // LEDs
	DDRB |= (1 << 5);
	DDRC |= (1 << 3);

}