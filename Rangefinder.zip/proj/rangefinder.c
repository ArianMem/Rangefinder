/* NOTE TO GRADER *************************

I have separated my project into different
.c files that are responsible for initializations
of key components. I kept the ISRs all in this file
to make it easier to grade. I declare all of my
function prototypes in rangefinder.h

If you can't find something or have any questions
regarding my code, please contact me at

memari@usc.edu

and I will reply very quickly.

Thank you!

******************************************/

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include "lcd.h"
#include <stdio.h>
#include <avr/interrupt.h>
#include "rangefinder.h"
#include "encoder.h"
#include <avr/eeprom.h>
#define FOSC 16000000           // Clock frequency
#define BAUD 9600               // Baud rate used
#define MYUBRR FOSC/16/BAUD-1 

// Define State & Volatile Vars
volatile unsigned int Yutong = 0;
volatile unsigned long int objRangeCM;
volatile unsigned long int objRangeMM;
volatile char state = 0;
volatile char endPulseFlag = 0;
volatile char EEPROMflag = 1;
volatile unsigned int pulseCounter;
volatile char overMaxdistance = 0;
volatile char tooClose = 0;
volatile unsigned char a, b;
volatile unsigned char temp;
volatile unsigned int count = 0;
volatile unsigned char new_state, old_state;
volatile int EEPROMval;
volatile char serialFlag = 0;
volatile int i = 0;
volatile char receivedString[7];
volatile int MMNumChars = 0;
volatile int num1 = 0;
volatile int receivedMinimumDistance = 0;

int main(void){

// Initializations of lcd, interrupts
	lcd_init();
	sei();

// ISR FOR THE RANGEFINDER

    // Set to CTC mode;
    TCCR1B |= (1 << WGM12);
    
    // Enable Timer Interrupt
    TIMSK1 |= (1 << OCIE1A);

    // Load the MAX count
    OCR1A = 46400;

// Register initializations for rangefinder

	// Initialize registers for signal to sensor
    DDRD |= (1 << 2); // Rangefinder output
    DDRD &= ~(1 << 3); // Rangefinder input

    // Setting up Pin Change ISR for rangefinder
    PCICR |= (1 << PCIE2);
    PCMSK2 |= (1 << PCINT19);


	//Initialize pulse ingredient
	int pulseValue = 0;

    // Hardware initializations
	buzzerInit();
	encoderInit();
	button_led_init();
	serialInitilize();

	// Splash and clear
	lcd_writecommand(1);
	lcd_stringout("Arian Memari");
	_delay_ms(400);
	lcd_writecommand(1);

    // Printing out initial LCD interface
   	lcd_moveto(0,0);
    lcd_stringout("Single: ");
	lcd_moveto(1,0);

/* EEPROM Initialization *******************/

	EEPROMcount();

/*************************************************/


	while (1) { 	// Begin our infinite loop

		// Did encoder state change?
		if (new_state != old_state) {
			
			// Update EEPROM flag
			EEPROMflag = 0;

			// Output count to LCD
			lcd_moveto(1,0);
			
			char date[30];
			lcd_moveto(1,4);
			snprintf(date, 30, "%3d", count);
			lcd_stringout(date);
			eeprom_update_word((void *) 100, count);		
		}

        // State machine
        if (state == 0){

        	// Single fire distance retrieval
            if (checkInput(1) == 0){
            	lcd_moveto(0,8);
                pulseValue = getPulseWidth(pulseValue);
            	printObjectDistance(pulseValue);
            }

            else if (checkInput(2) == 0){
	            // Printing out "Repeat" mode then clear
	            lcd_moveto(0,0);
	            lcd_stringout("Repeat: ");
		      	printLCDinterface();
            	state = 1;
            }
        }

        // Continously grab values
        else if (state == 1){

            if (checkInput(2) == 0){
	            // Printing out "Single mode" then clear
	   			lcd_moveto(0,0);
	            lcd_stringout("Single");
	           	printLCDinterface();
	           	state = 0;
            }

        	else{
	            lcd_moveto(0,8);
	            pulseValue = getPulseWidth(pulseValue);
	            printObjectDistance(pulseValue);
        	}
        }

        //SERIAL
        if (serialFlag == 1){

	        // Message received from remote device?
	        lcd_moveto(1,9);

	        // Convert string to numbers
	   		sscanf(receivedString, "%d", &num1);

	    	// Combining received numbers
			receivedMinimumDistance = num1/10;
			int decimalPlace = num1 % 10;

			char tempBuff[6];
			snprintf(tempBuff, 6, "%3d.%d", receivedMinimumDistance, 
				decimalPlace);
	        lcd_stringout(tempBuff);

	    	// Set flag off
        	serialFlag = 0;
        }
	}
}

char checkInput(char bit)
{
    if ((PINC & (1 << bit)) != 0){
        return(1);
    }

    else{
    	_delay_ms(5);
    	while ((PINC & (1 << bit)) != 0){}
		_delay_ms(5);
        return(0);
    }
}

int getPulseWidth(int temp){

	// A signal is sent to sensor
	// Setting the BIT2 slot to be an output
	PORTD |= (1 << 2);

	// Delay 10 MICROseconds
	_delay_us(10);

	// Receive the measurement
	// once pulse has reached the end
	if (endPulseFlag == 1){
		temp = pulseCounter;
	}

	// Now turn it off
	PORTD &= ~(1 << 2);

	// Delay again
	_delay_us(10);

	return temp;
}

void printObjectDistance (int x){
	char sentString[7];

	// Calculate and convert the count value
	// into cm
	objRangeMM = ((x * 10)/58)/2;
	objRangeCM = objRangeMM/10;

	//Checking to see if the width exceeds
	//the Max Range
	if (objRangeCM > 400){
		lcd_moveto(0,8);
		lcd_stringout("Far..");
	}
  	
	else{

		if (objRangeCM < count || objRangeCM < EEPROMval || 
			objRangeCM < receivedMinimumDistance){

			// Play the note!
			tooClose = 1;
		}

		lcd_moveto(0,8);
		char buff[6];
		snprintf(buff, 6, "%3d.%d", abs(objRangeCM), abs(objRangeMM % 10));
		lcd_stringout(buff);

		// Sending distance in MM to serial device
		snprintf(sentString, 7, "@%d$", objRangeMM);
		serial_stringout(sentString);

		//  If the local unit is closer, the green LED lights up (GREEN)
		if (objRangeCM < receivedMinimumDistance){
			PORTC &= ~(1 << 3);
			PORTB |= (1 << 5);
		}

		// If the remote unit is closer, the red LED lights up (RED)
		else if (objRangeCM > receivedMinimumDistance){
			PORTB &= ~(1 << 5);
			PORTC |= (1 << 3);
		}

		// Same distance
		else if (objRangeCM == receivedMinimumDistance){
			PORTB &= ~(1 << 5);
			PORTC &= ~(1 << 3);
		}
	}
}

// Prints the standardized LCD screen
void printLCDinterface(){

	if (EEPROMflag == 1){
		EEPROMcount();
	}

	else{
		char date[30];
		lcd_moveto(1,4);
		snprintf(date, 30, "%3d", count);
		lcd_stringout(date);
	}
}

void EEPROMcount(){
	EEPROMval = eeprom_read_word((void *) 100);
	int defMinD = 10;
	char initMin[30];
	lcd_moveto(1,0);
	lcd_stringout("Min=");

	if (EEPROMval > 400 || EEPROMval < 1){
		snprintf(initMin, 30, "%3d", defMinD);
		lcd_stringout(initMin);
	}
	else{
		snprintf(initMin, 30, "%3d", EEPROMval);
		lcd_stringout(initMin);
	}
}

void serial_init(unsigned short ubrr_value)
{

    // Set up USART0 registers
    UCSR0B |= (1 << RXCIE0);    // Enable receiver interrupts
    UCSR0C = (3 << UCSZ00);     // Async., no parity,
    
    // Enable tri-state
    // (Port C, bit 5)
    DDRC |= (1 << 5);
}

void serial_txchar(char ch)
{
    // Wait for transmitter data register empty
    while ((UCSR0A & (1<<UDRE0)) == 0);
    UDR0 = ch;
}

void serial_stringout(char *s)
{

    // Call serial_txchar in loop to send a string
    int j;
    for (j = 0; j < 7; j++){
        serial_txchar(s[j]);
    }
}

// Serial ISR
ISR(USART_RX_vect)
{	

    // Handle received character
    char ch;

    ch = UDR0;  // Get the received character

    if (ch == '@'){
    	// Data started flowing
    	i = 0;
    	serialFlag = 2;
    }

    if (serialFlag == 2 && (ch >= '0' && ch <= '9' || ch == '$')){
    	if (ch == '$' && i < 5 && i > 0){
    		receivedString[i] = '\0';
    		serialFlag = 1;
    	}

    	else{
    		receivedString[i] = ch;
    		i++;
    	}
    }
}

// Timer ISR for Processing
// the Sensor Output
// It increments every 10ms
ISR(TIMER1_COMPA_vect){	
	TCNT1 = 0;
	overMaxdistance = 1;
}

// Pin Change Interrupt ISR
ISR(PCINT2_vect){

	// Rangefinder sends signal.
	// Reset timer & flag. Starting timer.
	// Set prescalar and start counter
	if ((PIND & (1 << 3)) == (1 << 3)){
		TCNT1 = 0; 					
		endPulseFlag = 0;			
	    TCCR1B |= (1 << CS11);
	}

	// Receive the measurement
	// once pulse has reached the end
	if ((PIND & (1 << 3)) == 0){
		TCCR1B &= ~(1 << CS11);
		pulseCounter = TCNT1;
		endPulseFlag = 1;
	}
}

// Play a tone at the frequency specified for one second
ISR(TIMER0_COMPA_vect){
	if (Yutong < 100 && tooClose == 1){
		Yutong = Yutong+1;

		// Make PC4 low
		PORTC ^= (1 << PC4);
	}

	else {
		//TCNT0 = 0;
		tooClose = 0;
		Yutong = 0;
		PORTC &= ~(1 << PC4);
	}
}


// ISR to control state machine
ISR(PCINT0_vect){

	temp = PINB;

	a = (temp & (1 << 3)) != 0;
	b = (temp & (1 << 4)) != 0;

	if (count > 400){
		count = 400;
	}

	else if (count < 1){
		count = 1;
	}

	// Construction of State Machine
	if (old_state == 0) {
		
		// Handle A and B inputs for state 0
		if (a == 1){
			count++;
			new_state = 1;
		}
		
		else if (b == 1){
			count--;
			new_state = 2;
		}
		
	}
	
	else if (old_state == 1) {
		
		// Handle A and B inputs for state 1
		if (a == 0){
			count--;
			new_state = 0;
		}
		
		else if (b == 1){
			count++;
			new_state = 3;
		}
	}
	
	else if (old_state == 2) {
		
		// Handle A and B inputs for state 2
		if (a == 1){
			count--;
			new_state = 3;
		}
		
		else if (b == 0){
			count++;
			new_state = 0;
		}
	}
	
	else {   // old_state = 3
		
		// Handle A and B inputs for state 3
		if (a == 0){
			count++;
			new_state = 2;
		}
		
		else if (b == 0){
			count--;
			new_state = 1;
		}
	}
	
	if (new_state != old_state) {
		old_state = new_state;
	}
}